import { useCallback, useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';

const ICE_SERVERS = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
  { urls: 'stun:stun2.l.google.com:19302' }
];

const SOCKET_URL =
  import.meta.env.VITE_SOCKET_URL ||
  (typeof window !== 'undefined' && window.location.hostname === 'localhost'
    ? 'http://localhost:4000'
    : `${window.location.origin}`);

export function useVoiceChat() {
  const socketRef = useRef(null);
  const peerRef = useRef(null);
  const localStreamRef = useRef(null);
  const remoteStreamRef = useRef(null);

  const [status, setStatus] = useState('idle'); // idle | waiting | matched | error
  const [partner, setPartner] = useState(null);
  const [roomId, setRoomId] = useState(null);
  const [initiator, setInitiator] = useState(false);
  const [error, setError] = useState(null);
  const [localStream, setLocalStream] = useState(null);
  const [remoteStream, setRemoteStream] = useState(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [lastEndedReason, setLastEndedReason] = useState(null);

  const resetState = useCallback(() => {
    if (peerRef.current) {
      try {
        peerRef.current.close();
      } catch (err) {
        // no-op
      }
      peerRef.current = null;
    }

    if (remoteStreamRef.current) {
      remoteStreamRef.current.getTracks().forEach((track) => track.stop());
      remoteStreamRef.current = null;
    }

    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
      localStreamRef.current = null;
      setLocalStream(null);
    }

    setStatus('idle');
    setPartner(null);
    setRoomId(null);
    setInitiator(false);
    setError(null);
    setRemoteStream(null);
  }, []);

  const ensureSocket = useCallback(() => {
    if (socketRef.current) {
      return socketRef.current;
    }

    const socket = io(SOCKET_URL, {
      autoConnect: false,
      transports: ['websocket']
    });

    socket.on('connect_error', (err) => {
      setError(err?.message || 'Unable to connect to signaling server.');
      setStatus('error');
    });

    socket.on('queue:status', ({ status: queueStatus }) => {
      if (queueStatus === 'waiting') {
        setStatus('waiting');
      } else if (queueStatus === 'idle') {
        setStatus('idle');
      }
    });

    socket.on('queue:error', ({ message }) => {
      setError(message);
      setStatus('error');
    });

    socket.on('queue:matched', async ({ roomId: matchedRoomId, partner: partnerInfo, initiator: isInitiator }) => {
      setStatus('matched');
      setPartner(partnerInfo);
      setRoomId(matchedRoomId);
      setInitiator(isInitiator);
      setLastEndedReason(null);
      try {
        await startPeerConnection({ roomId: matchedRoomId, initiator: isInitiator });
      } catch (err) {
        setError(err.message || 'Failed to establish call.');
        socket.emit('room:end', { roomId: matchedRoomId, reason: 'setup_failed' });
        resetState();
        setStatus('error');
      }
    });

    socket.on('signal:offer', async ({ offer }) => {
      if (!peerRef.current) {
        return;
      }
      try {
        await peerRef.current.setRemoteDescription(new RTCSessionDescription(offer));
        const answer = await peerRef.current.createAnswer();
        await peerRef.current.setLocalDescription(answer);
        socket.emit('signal:answer', { roomId: roomId || peerRef.current.roomId, answer });
      } catch (err) {
        setError(err.message || 'Unable to accept the call offer.');
      }
    });

    socket.on('signal:answer', async ({ answer }) => {
      if (!peerRef.current) {
        return;
      }
      try {
        await peerRef.current.setRemoteDescription(new RTCSessionDescription(answer));
      } catch (err) {
        setError(err.message || 'Unable to process answer from partner.');
      }
    });

    socket.on('signal:ice', async ({ candidate }) => {
      if (!peerRef.current || !candidate) {
        return;
      }
      try {
        await peerRef.current.addIceCandidate(new RTCIceCandidate(candidate));
      } catch (err) {
        setError(err.message || 'Unable to add ICE candidate.');
      }
    });

    socket.on('room:ended', ({ reason }) => {
      teardownPeer(reason || 'partner_left');
    });

    socketRef.current = socket;
    return socket;
  }, [resetState, roomId]);

  const prepareLocalStream = useCallback(async () => {
    if (localStreamRef.current) {
      return localStreamRef.current;
    }
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    localStreamRef.current = stream;
    setLocalStream(stream);
    setIsMuted(false);
    return stream;
  }, []);

  const startPeerConnection = useCallback(
    async ({ roomId: activeRoomId, initiator: isInitiator }) => {
      const socket = ensureSocket();
      const local = await prepareLocalStream();

      const peer = new RTCPeerConnection({ iceServers: ICE_SERVERS });
      peer.roomId = activeRoomId;

      peer.onicecandidate = (event) => {
        if (event.candidate) {
          socket.emit('signal:ice', { roomId: activeRoomId, candidate: event.candidate });
        }
      };

      peer.ontrack = (event) => {
        const [stream] = event.streams;
        if (stream) {
          remoteStreamRef.current = stream;
          setRemoteStream(stream);
        }
      };

      peer.onconnectionstatechange = () => {
        if (peer.connectionState === 'failed' || peer.connectionState === 'disconnected') {
          teardownPeer(peer.connectionState);
        }
      };

      local.getTracks().forEach((track) => peer.addTrack(track, local));

      peerRef.current = peer;

      if (isInitiator) {
        const offer = await peer.createOffer();
        await peer.setLocalDescription(offer);
        socket.emit('signal:offer', { roomId: activeRoomId, offer });
      }
    },
    [ensureSocket, prepareLocalStream]
  );

  const joinQueue = useCallback(
    async ({ displayName }) => {
      setError(null);
      setLastEndedReason(null);
      setIsConnecting(true);
      try {
        await prepareLocalStream();
      } catch (err) {
        setError(err.message || 'Microphone permission is required.');
        setStatus('error');
        setIsConnecting(false);
        return;
      }

      const socket = ensureSocket();
      if (!socket.connected) {
        socket.connect();
      }
      socket.emit('queue:join', { displayName });
      setStatus('waiting');
      setIsConnecting(false);
    },
    [ensureSocket, prepareLocalStream]
  );

  const cancelQueue = useCallback(() => {
    const socket = ensureSocket();
    socket.emit('queue:cancel');
    setStatus('idle');
  }, [ensureSocket]);

  const toggleMute = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) {
      return;
    }
    const anyEnabled = stream.getAudioTracks().some((track) => track.enabled);
    stream.getAudioTracks().forEach((track) => {
      track.enabled = !anyEnabled;
    });
    setIsMuted(anyEnabled);
  }, []);

  const teardownPeer = useCallback(
    (reason) => {
      if (peerRef.current) {
        peerRef.current.ontrack = null;
        peerRef.current.onicecandidate = null;
        peerRef.current.onconnectionstatechange = null;
        peerRef.current.getSenders().forEach((sender) => {
          if (sender.track) {
            sender.track.stop();
          }
        });
        peerRef.current.close();
        peerRef.current = null;
      }

      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((track) => track.stop());
        localStreamRef.current = null;
        setLocalStream(null);
      }
      setIsMuted(false);

      if (remoteStreamRef.current) {
        remoteStreamRef.current.getTracks().forEach((track) => track.stop());
        remoteStreamRef.current = null;
      }

      setRemoteStream(null);
      setPartner(null);
      setRoomId(null);
      setStatus('idle');
      setLastEndedReason(reason || 'ended');
    },
    []
  );

  const endCall = useCallback(
    (reason = 'ended_by_user') => {
      const socket = ensureSocket();
      if (roomId) {
        socket.emit('room:end', { roomId, reason });
      }
      teardownPeer(reason);
    },
    [ensureSocket, roomId, teardownPeer]
  );

  const blockPartner = useCallback(() => {
    if (!partner || !roomId) {
      return;
    }
    const socket = ensureSocket();
    socket.emit('room:block', { roomId, targetId: partner.id });
    teardownPeer('blocked');
  }, [ensureSocket, partner, roomId, teardownPeer]);

  useEffect(() => {
    const socket = ensureSocket();
    if (!socket.connected) {
      socket.connect();
    }
    return () => {
      socket.disconnect();
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((track) => track.stop());
        localStreamRef.current = null;
      }
      if (remoteStreamRef.current) {
        remoteStreamRef.current.getTracks().forEach((track) => track.stop());
        remoteStreamRef.current = null;
      }
      if (peerRef.current) {
        peerRef.current.close();
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    status,
    partner,
    roomId,
    initiator,
    error,
    localStream,
    remoteStream,
    isMuted,
    isConnecting,
    lastEndedReason,
    joinQueue,
    cancelQueue,
    endCall,
    toggleMute,
    blockPartner
  };
}

export function useMediaStreamAudio(elementRef, stream) {
  useEffect(() => {
    if (!elementRef.current) {
      return;
    }
    if ('srcObject' in elementRef.current) {
      elementRef.current.srcObject = stream || null;
    } else if (stream) {
      elementRef.current.src = window.URL.createObjectURL(stream);
    } else {
      elementRef.current.src = '';
    }
  }, [elementRef, stream]);
}
