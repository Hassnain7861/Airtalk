import { useEffect, useMemo, useRef, useState } from 'react';
import './App.css';
import { useVoiceChat, useMediaStreamAudio } from './hooks/useVoiceChat';

const formatDuration = (milliseconds) => {
  const totalSeconds = Math.floor(milliseconds / 1000);
  const minutes = Math.floor(totalSeconds / 60)
    .toString()
    .padStart(2, '0');
  const seconds = (totalSeconds % 60).toString().padStart(2, '0');
  return `${minutes}:${seconds}`;
};

function App() {
  const [displayName, setDisplayName] = useState('');
  const [callStart, setCallStart] = useState(null);
  const [elapsed, setElapsed] = useState(0);

  const localAudioRef = useRef(null);
  const remoteAudioRef = useRef(null);

  const {
    status,
    partner,
    error,
    localStream,
    remoteStream,
    isMuted,
    isConnecting,
    lastEndedReason,
    joinQueue,
    cancelQueue,
    endCall,
    toggleMute,
    blockPartner
  } = useVoiceChat();

  useMediaStreamAudio(localAudioRef, localStream);
  useMediaStreamAudio(remoteAudioRef, remoteStream);

  useEffect(() => {
    if (status === 'matched') {
      setCallStart(Date.now());
    } else if (status === 'idle') {
      setCallStart(null);
      setElapsed(0);
    }
  }, [status]);

  useEffect(() => {
    if (!callStart || status !== 'matched') {
      return undefined;
    }
    const interval = setInterval(() => {
      setElapsed(Date.now() - callStart);
    }, 1000);
    return () => clearInterval(interval);
  }, [callStart, status]);

  const actionLabel = useMemo(() => {
    if (status === 'matched') {
      return 'End Call';
    }
    if (status === 'waiting') {
      return 'Cancel Search';
    }
    return 'Start Talking';
  }, [status]);

  const statusLabel = useMemo(() => {
    switch (status) {
      case 'waiting':
        return 'Finding someone to talk to…';
      case 'matched':
        return `You are connected with ${partner?.displayName || 'someone new'}`;
      case 'error':
        return 'Something went wrong. Please try again.';
      default:
        return 'Ready when you are.';
    }
  }, [status, partner]);

  const handlePrimaryAction = async () => {
    if (status === 'matched') {
      endCall('ended_by_user');
      return;
    }
    if (status === 'waiting') {
      cancelQueue();
      return;
    }
    await joinQueue({ displayName });
  };

  const showNameField = status === 'idle' || status === 'error';
  const callInformation = status === 'matched' && partner;

  return (
    <div className="app-shell">
      <header className="hero">
        <div className="hero-copy">
          <span className="badge">Live voice chats</span>
          <h1>Meet real people in real time.</h1>
          <p>
            AirTalk connects you to a worldwide community for spontaneous voice conversations. Join the queue,
            match instantly, and start a human conversation in just one click.
          </p>
          <ul className="hero-highlights">
            <li>One-on-one voice calls</li>
            <li>Smart matching engine</li>
            <li>Secure and anonymous</li>
          </ul>
        </div>
        <div className="hero-panel">
          <div className="panel-header">
            <h2>Talk to a stranger</h2>
            <p>{statusLabel}</p>
            {lastEndedReason && (
              <span className="ended-label">
                Last call ended: {lastEndedReason.replace(/_/g, ' ')}
              </span>
            )}
          </div>
          {error && <div className="panel-error">{error}</div>}

          {showNameField && (
            <label className="field">
              <span>Display name</span>
              <input
                type="text"
                placeholder="Guest"
                value={displayName}
                onChange={(event) => setDisplayName(event.target.value)}
              />
            </label>
          )}

          {callInformation && (
            <div className="call-details">
              <div className="avatar">{partner.displayName.charAt(0).toUpperCase()}</div>
              <div>
                <p className="partner-name">{partner.displayName}</p>
                <p className="time">{formatDuration(elapsed)}</p>
              </div>
            </div>
          )}

          <div className="panel-actions">
            <button
              className={`primary ${status}`}
              onClick={handlePrimaryAction}
              disabled={isConnecting}
            >
              {isConnecting ? 'Connecting…' : actionLabel}
            </button>
            {status === 'matched' && (
              <>
                <button className="secondary" onClick={toggleMute}>
                  {isMuted ? 'Unmute' : 'Mute Mic'}
                </button>
                <button className="danger" onClick={blockPartner}>
                  Block User
                </button>
              </>
            )}
          </div>

          <audio ref={localAudioRef} muted playsInline />
          <audio ref={remoteAudioRef} autoPlay playsInline />
        </div>
      </header>

      <main>
        <section className="section features">
          <h2>Why people choose AirTalk</h2>
          <div className="feature-grid">
            <article>
              <h3>Fast pairing</h3>
              <p>Tap the button and the matching engine instantly connects you with the next available caller.</p>
            </article>
            <article>
              <h3>Voice-first design</h3>
              <p>High-quality WebRTC audio keeps every conversation crisp, with automatic network adaptation.</p>
            </article>
            <article>
              <h3>Privacy controls</h3>
              <p>Stay anonymous, choose your display name, and end any conversation with a single click.</p>
            </article>
            <article>
              <h3>Global reach</h3>
              <p>Thousands of people join daily, so you can chat with someone new no matter the time of day.</p>
            </article>
          </div>
        </section>

        <section className="section how-it-works">
          <h2>How it works</h2>
          <ol>
            <li>
              <strong>Set a name.</strong> Choose how you want to appear to other callers.
            </li>
            <li>
              <strong>Join the queue.</strong> We pair you with the next person who&apos;s ready to talk.
            </li>
            <li>
              <strong>Start chatting.</strong> Share stories, ideas, or just say hello—it’s your conversation.
            </li>
          </ol>
        </section>

        <section className="section safety">
          <h2>Safety & respect</h2>
          <p>
            We want every voice on the platform to feel heard. Please keep conversations respectful, report any bad
            behaviour, and remember that recording or sharing calls without consent is not allowed.
          </p>
        </section>
      </main>

      <footer className="footer">
        <p>© {new Date().getFullYear()} AirTalk. Built for meaningful conversations.</p>
      </footer>
    </div>
  );
}

export default App;
