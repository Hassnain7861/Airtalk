const path = require('path');
const fs = require('fs');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const PORT = process.env.PORT || 4000;
const CLIENT_DIST = path.resolve(__dirname, '../../client/dist');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(CLIENT_DIST));

app.get('/health', (_, res) => {
  res.json({ status: 'ok' });
});

app.get(/^\/(?!socket\.io).*/, (req, res) => {
  if (req.method !== 'GET') {
    res.status(404).end();
    return;
  }

  const indexFile = path.join(CLIENT_DIST, 'index.html');
  if (!fs.existsSync(indexFile)) {
    res
      .status(200)
      .send('Frontend build not found. Run "npm run build" inside the client directory to generate the UI bundle.');
    return;
  }

  res.sendFile(indexFile);
});

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

/**
 * In-memory structures to pair users and track active rooms.
 */
const waitingQueue = [];
const rooms = new Map();

function findPartner(socket) {
  for (let index = 0; index < waitingQueue.length; index += 1) {
    const candidate = waitingQueue[index];
    if (candidate.id === socket.id) {
      continue;
    }

    const candidateSocket = io.sockets.sockets.get(candidate.id);
    if (!candidateSocket) {
      continue;
    }

    const socketBlockedById = socket.data.blockedIds?.has(candidate.id);
    const socketBlockedByIp =
      candidateSocket.data?.ip && socket.data.blockedIps?.has(candidateSocket.data.ip);
    const candidateBlockedById = candidateSocket.data?.blockedIds?.has(socket.id);
    const candidateBlockedByIp =
      socket.data?.ip && candidateSocket.data?.blockedIps?.has(socket.data.ip);

    if (socketBlockedById || socketBlockedByIp || candidateBlockedById || candidateBlockedByIp) {
      continue;
    }

    waitingQueue.splice(index, 1);
    return candidate;
  }
  return null;
}

function endRoom(roomId, reason = 'partner_left') {
  const room = rooms.get(roomId);
  if (!room) {
    return;
  }

  room.participants.forEach((participantId) => {
    const participant = io.sockets.sockets.get(participantId);
    if (participant) {
      participant.emit('room:ended', { reason });
      participant.data.currentRoom = null;
    }
  });

  rooms.delete(roomId);
}

io.on('connection', (socket) => {
  socket.data.ip = socket.handshake.address;
  socket.data.displayName = null;
  socket.data.currentRoom = null;
  socket.data.queuedAt = null;
  socket.data.blockedIds = new Set();
  socket.data.blockedIps = new Set();

  socket.on('queue:join', ({ displayName } = {}) => {
    if (socket.data.currentRoom) {
      socket.emit('queue:error', { message: 'Already connected to someone.' });
      return;
    }

    if (waitingQueue.some((queued) => queued.id === socket.id)) {
      socket.emit('queue:status', { status: 'waiting' });
      return;
    }

    socket.data.displayName = displayName?.trim() || `Guest-${socket.id.slice(-4)}`;
    socket.data.queuedAt = Date.now();
    waitingQueue.push({
      id: socket.id,
      displayName: socket.data.displayName,
      queuedAt: socket.data.queuedAt,
      ip: socket.data.ip
    });

    socket.emit('queue:status', { status: 'waiting' });
    const partner = findPartner(socket);

    if (partner) {
      const ownIndex = waitingQueue.findIndex((entry) => entry.id === socket.id);
      if (ownIndex !== -1) {
        waitingQueue.splice(ownIndex, 1);
      }

      const roomId = uuidv4();
      const partnerSocket = io.sockets.sockets.get(partner.id);
      if (!partnerSocket) {
        socket.emit('queue:status', { status: 'waiting' });
        return;
      }

      rooms.set(roomId, {
        participants: [socket.id, partner.id],
        createdAt: Date.now()
      });

      socket.data.currentRoom = roomId;
      partnerSocket.data.currentRoom = roomId;

      socket.emit('queue:matched', {
        roomId,
        partner: {
          id: partner.id,
          displayName: partner.displayName
        },
        initiator: true
      });

      partnerSocket.emit('queue:matched', {
        roomId,
        partner: {
          id: socket.id,
          displayName: socket.data.displayName
        },
        initiator: false
      });
    }
  });

  socket.on('queue:cancel', () => {
    const index = waitingQueue.findIndex((queued) => queued.id === socket.id);
    if (index !== -1) {
      waitingQueue.splice(index, 1);
    }
    socket.data.queuedAt = null;
    socket.emit('queue:status', { status: 'idle' });
  });

  socket.on('signal:offer', ({ roomId, offer }) => {
    const room = rooms.get(roomId);
    if (!room || !room.participants.includes(socket.id)) {
      return;
    }

    room.participants
      .filter((participantId) => participantId !== socket.id)
      .forEach((participantId) => {
        const peer = io.sockets.sockets.get(participantId);
        if (peer) {
          peer.emit('signal:offer', { offer });
        }
      });
  });

  socket.on('signal:answer', ({ roomId, answer }) => {
    const room = rooms.get(roomId);
    if (!room || !room.participants.includes(socket.id)) {
      return;
    }

    room.participants
      .filter((participantId) => participantId !== socket.id)
      .forEach((participantId) => {
        const peer = io.sockets.sockets.get(participantId);
        if (peer) {
          peer.emit('signal:answer', { answer });
        }
      });
  });

  socket.on('signal:ice', ({ roomId, candidate }) => {
    const room = rooms.get(roomId);
    if (!room || !room.participants.includes(socket.id)) {
      return;
    }

    room.participants
      .filter((participantId) => participantId !== socket.id)
      .forEach((participantId) => {
        const peer = io.sockets.sockets.get(participantId);
        if (peer) {
          peer.emit('signal:ice', { candidate });
        }
      });
  });

  socket.on('room:end', ({ roomId, reason = 'ended' } = {}) => {
    if (roomId && rooms.has(roomId)) {
      endRoom(roomId, reason);
    }
  });

  socket.on('room:block', ({ roomId, targetId }) => {
    if (!roomId || !rooms.has(roomId)) {
      return;
    }

    const room = rooms.get(roomId);
    if (!room.participants.includes(socket.id)) {
      return;
    }

    const targetSocket = io.sockets.sockets.get(targetId);
    if (targetSocket) {
      socket.data.blockedIds.add(targetId);
      if (targetSocket.data?.ip) {
        socket.data.blockedIps.add(targetSocket.data.ip);
      }
    }

    endRoom(roomId, 'blocked');
  });

  socket.on('disconnect', () => {
    const queueIndex = waitingQueue.findIndex((queued) => queued.id === socket.id);
    if (queueIndex !== -1) {
      waitingQueue.splice(queueIndex, 1);
    }

    const currentRoom = socket.data.currentRoom;
    if (currentRoom) {
      endRoom(currentRoom, 'partner_disconnected');
    }
  });
});

server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
